﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AudioDevices
{
    public enum Category
    {
        HipHop,
        Jazz,
        Pop,
        Rock,
        Reggae
    }
}